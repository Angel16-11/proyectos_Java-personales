
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.*;
import javax.imageio.ImageIO;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

public class TarjetaCumpleRuth extends JPanel implements ActionListener {

    private Timer timer;
    private double t = 0;
    private ArrayList<Point> puntos = new ArrayList<>();
    private BufferedImage fondo;

    public TarjetaCumpleRuth() {
        setBackground(Color.BLACK);
        timer = new Timer(30, this);
        timer.start();

        try {
            fondo = ImageIO.read(new File("tarjeta_ruth_final.png"));
        } catch (IOException e) {
            System.out.println("Error cargando imagen: " + e.getMessage());
        }
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2d = (Graphics2D) g;

        if (fondo != null) {
            g.drawImage(fondo, 0, 0, getWidth(), getHeight(), null);
        }

        g2d.setColor(Color.RED);
        for (Point p : puntos) {
            g2d.fillOval(p.x, p.y, 2, 2);
        }

        if (t <= Math.PI * 2) {
            double x = 16 * Math.pow(Math.sin(t), 3);
            double y = 13 * Math.cos(t) - 5 * Math.cos(2 * t)
                     - 2 * Math.cos(3 * t) - Math.cos(4 * t);
            int esc = 10;
            int px = getWidth() / 2 + (int)(x * esc);
            int py = getHeight() / 2 - 200 - (int)(y * esc);
            puntos.add(new Point(px, py));
        }

        if (t > Math.PI * 2) {
            g.setColor(new Color(0, 0, 0, 180));
            g.fillRect(0, getHeight() - 60, getWidth(), 40);
            g.setColor(Color.WHITE);
            g.setFont(new Font("SansSerif", Font.BOLD, 20));
            g.drawString("¡Feliz cumpleaños Ruth Ariana! 🎉💖", 30, getHeight() - 35);
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (t <= Math.PI * 2) {
            t += 0.03; // velocidad más suave
        }
        repaint();
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("Tarjeta para Ruth Ariana");
        TarjetaCumpleRuth panel = new TarjetaCumpleRuth();
        frame.add(panel);
        frame.setSize(700, 700);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }
}
